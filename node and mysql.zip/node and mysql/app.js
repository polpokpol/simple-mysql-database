var faker = require("faker");
var mysql = require('mysql');

var connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'roskimoski',
  database: 'join_us',
  // insecureAuth : true
});
connection.connect();


// var q = 'SELECT * FROM users';
// connection.query(q, function(error, results, fields){
// 	if(error) throw error;
// 	console.log(results[1].email); //yung zero gamit lang nyan para maalis ung list.
// });

// connection.end();

// var article = {
//   author: 'Alex Booker',
//   title: 'Git tutorial',
//   body: 'foo bar'
// };

// var query = connection.query('insert into articles set ?', article, function (err, result) {
//   if (err) {
//     console.error(err);
//     return;
//   }
//   console.error(result);
// });

// var person = {email: faker.internet.email(),
// 				created_at: };

// connection.query('INSERT INTO users SET ?', person, function(wrong, result){
// 	if(wrong) throw wrong;
// 	console.log(result); 

// });

// connection.end();

var data = [];

for(var i = 0; i < 500; i++){

	data.push([
		faker.internet.email(),
		faker.date.past()
		]);
}


var q = 'INSERT INTO users (email, created_at) VALUES ?';

connection.query(q, [data], function(err, result){
	console.log(err);
	console.log(result);

});

connection.end();