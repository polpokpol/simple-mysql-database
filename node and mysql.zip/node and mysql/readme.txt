node app.js 	-----> execute this first for local testing like
		localhost:8888 in your browser



this is the one i am using when i am putting it to live server. Its not perfect yet and only temporary live server.
http-server C:\Users\Mcrey\Documents\node and mysql\joinus\app.js
