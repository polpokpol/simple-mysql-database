This is a very simple database, I wish i can add more features unto it but i dont know how to use node.js i just followed along the 
tutorial in the node.js section. :)