-- SHOW DATABASES;
-- USE ig_clone;

-- DROP DATABASE ig_clone;
-- CREATE DATABASE ig_clone;
-- USE ig_clone;
-- USE tv_review_app;


-- SELECT title, released_year FROM books ORDER BY released_year DESC LIMIT 5, 216516166;
-- SELECT title, author_fname, author_lname FROM books ORDER BY released_year, 1, 2;
-- SELECT title FROM books LIMIT 3, 1;

-- SELECT DISTINCT author_lname, author_fname FROM books;
-- SELECT DISTINCT CONCAT(author_lname, " ", author_fname) FROM books;

-- SELECT author_fname, author_lname FROM books ORDER BY released_year DESC;
-- SELECT DISTINCT author_lname, author_fname FROM books ORDER BY 1, 2
-- SELECT title, author_fname FROM books WHERE author_fname LIKE 'dave';
-- SELECT title, stock_quantity FROM books WHERE title LIKE '%\%%'; # TO USE LIKE PARATING MAY WHERE DAPAT
-- SELECT title, stock_quantity FROM books WHERE stock_quantity LIKE '___';

-- SELECT CONCAT_WS(" ", UPPER('my favorite author is'), UPPER(author_fname), UPPER(author_lname)) AS 'yell' FROM books ORDER BY author_lname;

-- SELECT COUNT(*) FROM books WHERE title LIKE '%the%';
-- SELECT title, author_fname, author_lname, COUNT(*) FROM books GROUP BY author_lname, author_fname;
-- SELECT released_year, COUNT(*) FROM books GROUP BY released_year;
-- SELECT CONCAT('it was released in ', released_year, ' and has ', COUNT(*), ' books') AS gago FROM books GROUP BY released_year
-- SELECT MAX(pages), title FROM books;
-- SELECT * FROM books WHERE pages = (SELECT MIN(pages) FROM books);
-- SELECT title, pages FROM books WHERE pages = (SELECT MIN(pages) FROM books)
-- SELECT title, pages FROM books ORDER BY pages LIMIT 1;

-- SELECT COUNT(title) FROM books;
-- SELECT released_year, COUNT(released_year) FROM books GROUP BY released_year;
-- SELECT SUM(stock_quantity) FROM books;
-- SELECT CONCAT(author_fname, " ", author_lname), AVG(released_year) FROM books GROUP BY author_lname, author_fname;
-- SELECT CONCAT(author_fname, " ", author_lname), pages FROM books WHERE pages = (SELECT MAX(pages) FROM books); --OR
-- SELECT CONCAT(author_fname, " ", author_lname), pages FROM books ORDER BY pages DESC LIMIT 1;
-- SELECT released_year, COUNT(*), AVG(pages) FROM books GROUP BY released_year ORDER BY released_year;

-- SELECT name, birthdate, DATEDIFF(NOW(), birthdate) FROM people WHERE name = "Larry";
-- SELECT birthdt, DATE_ADD(birthdt, INTERVAL 1 QUARTER) FROM people WHERE name = 'Larry';
-- SELECT birthdt, birthdt + INTERVAL 1 MONTH FROM people WHERE name = 'Larry';
-- SELECT name, CONCAT(name, " was born on ", birthdt + INTERVAL 1 MONTH + INTERVAL 3 MINUTE) FROM people WHERE name = "Larry";

-- SELECT name, birthdt, MINUTE(birthtime), DAYNAME(birthdt), MONTHNAME(birthdt), WEEK(birthdt) FROM people;
-- SELECT DATE_FORMAT(birthdt, '%M-%d-%Y and %h:%i') FROM people;


-- CREATE TABLE comments (content VARCHAR(100), time_created TIMESTAMP DEFAULT NOW() ON UPDATE CURRENT_TIMESTAMP);
-- INSERT INTO comments (content) VALUES ("baka nga");
-- SELECT time_created FROM comments ORDER BY time_created;
-- UPDATE comments SET content = 'Naniiiiiiiiiiiiiiiiiiiiii!' WHERE content = 'baka nga';
-- CREATE TABLE comments2 (content VARCHAR(100), time_created TIMESTAMP DEFAULT NOW() ON UPDATE NOW());
-- INSERT INTO comments2 (content) VALUES ("Like wtf!");
-- UPDATE comments2 SET content = 'oh yeah!' WHERE content = 'like wtf!';

-- SELECT CURTIME(), CURDATE(), DAYOFWEEK(NOW()), DAYNAME(NOW());
-- SELECT DATE_FORMAT(NOW(), '%M/%D/%Y');
-- SELECT DATE_FORMAT(NOW(), '%M %D at %h:%i');
-- CREATE TABLE tweets (content VARCHAR(100), username VARCHAR(20), time_created TIMESTAMP DEFAULT NOW() ON UPDATE NOW());
-- SELECT DATE_FORMAT(NOW(), '%W');

-- SELECT title, released_year FROM books WHERE released_year >= 2000 AND released_year <= 2015;
-- SELECT title, released_year FROM books WHERE released_year BETWEEN 2000 AND 2015;
-- SELECT title, released_year FROM books WHERE released_year NOT BETWEEN 2000 AND 2015;
 -- SELECT CAST('2016-05-09 11:03:06' AS DATETIME);


-- SELECT 
--     title, 
--     author_lname 
-- FROM books
-- WHERE author_lname='Carver' OR
--       author_lname='Lahiri' OR
--       author_lname='Smith';
-- SELECT title, author_lname FROM books WHERE author_lname IN ('Carver', 'Lahiri', 'Smith');
-- SELECT title, released_year FROM books WHERE released_year IN (2017, 1985);
-- SELECT title, released_year FROM books WHERE released_year >= 2000 AND released_year % 2 != 0;

-- SELECT title, released_year, CASE WHEN released_year >= 2000 THEN 'Modern Lit' ELSE '20th Century Lit' END AS 'alipin' FROM books;
-- SELECT title, stock_quantity, CASE WHEN stock_quantity >= 50 THEN '*' WHEN stock_quantity <= 100 THEN '**' ELSE '***' END FROM books;


-- SELECT * FROM books WHERE released_year < 1980;
-- SELECT * FROM books WHERE author_lname IN ('Lahiri') AND released_year > 2000;
-- SELECT * FROM books WHERE pages BETWEEN 100 AND 200;
-- SELECT * FROM books WHERE author_lname LIKE 'C%' OR author_lname LIKE 's%'; -- ORRRR   SELECT * FROM books WHERE SUBSTR(author_lname, 1, 1) IN ('C', 'S');
-- SELECT title, author_lname,
-- 	CASE WHEN title LIKE '%stories%' THEN 'Short Stories'
-- 	WHEN title LIKE '%Just Kids%' OR title LIKE '%heartbreaking work%' THEN 'Memoir'
-- 	ELSE 'Novel' END
-- 	AS 'TYPE'
-- 	 FROM books;
-- SELECT title, author_lname,
-- 	 CASE WHEN COUNT(*) = 2 THEN '2 books'
-- 	 WHEN COUNT(*) = 3 THEN '3 books'
-- 	 ELSE '1 book' END AS 'COUNT'
-- 	 FROM books 
-- 	 GROUP BY author_lname, author_fname 
-- 	 ORDER BY author_lname, author_fname;  -- ORRRR
-- SELECT title, author_lname,
-- 	CASE
-- 	WHEN COUNT(*) = 1 THEN '1 book'
-- 	ELSE CONCAT(COUNT(*), ' books')
-- 	END AS 'COUNT'
-- 	FROM books
-- 	GROUP BY author_lname, author_fname;


-- CREATE TABLE customers(id INT AUTO_INCREMENT PRIMARY KEY, first_name VARCHAR(100), last_name VARCHAR(100), email VARCHAR(100));
-- CREATE TABLE orders(
-- 	id INT AUTO_INCREMENT PRIMARY KEY,
-- 	order_date DATE,
-- 	amount DECIMAL(8, 2),
-- 	customer_id INT,
-- 	FOREIGN KEY(customer_id) REFERENCES customers(id)
-- );
-- INSERT INTO orders (order_date, amount, customer_id)
-- VALUES ('2016/02/10', 99.99, 1),
--        ('2017/11/11', 35.50, 1),
--        ('2014/12/12', 800.67, 2),
--        ('2015/01/03', 12.50, 2),
--        ('1999/04/11', 450.25, 5);



-- SELECT * FROM customers, orders WHERE customers.id = orders.customer_id;
-- SELECT first_name, last_name, order_date, amount FROM customers, orders WHERE customers.id = orders.customer_id;
-- SELECT * FROM customers JOIN orders ON customers.id = orders.customer_id;
-- SELECT first_name, last_name, order_date, amount FROM customers JOIN orders ON orders.customer_id = customers.id;
-- SELECT * FROM orders JOIN customers ON orders.customer_id = customers.id;
-- SELECT first_name, last_name, SUM(amount) AS total_amount FROM customers JOIN orders ON customers.id = orders.customer_id GROUP BY orders.customer_id ORDER BY total_amount;
-- SELECT
-- 	first_name, last_name, SUM(amount) AS 'kalahatan'
-- 	FROM orders JOIN customers
-- 	ON customers.id = orders.customer_id
-- 	GROUP BY orders.customer_id
-- 	ORDER BY kalahatan DESC;
-- SELECT * FROM customers LEFT JOIN orders ON customers.id = orders.customer_id;
-- SELECT first_name, last_name, order_date, IFNULL(SUM(amount), 0) AS total_amount FROM customers LEFT JOIN orders ON customers.id = orders.customer_id 
	-- GROUP BY customers.id ORDER BY total_amount;
-- SELECT * FROM customers RIGHT JOIN orders ON orders.customer_id = customers.id;

-- CREATE TABLE students(id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(100));
-- CREATE TABLE papers(title VARCHAR(100), grade INT, student_id INT, FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE);
-- SELECT name, title, grade FROM students, papers WHERE students.id = papers.student_id ORDER BY grade DESC;
-- SELECT name, IFNULL(title, 'MISSING'), IFNULL(grade, 0) as 'grade' FROM students LEFT JOIN papers ON students.id = papers.student_id ORDER BY id;
-- SELECT name, IFNULL(SUM(grade)/COUNT(*), 0) AS 'average' FROM students LEFT JOIN papers ON students.id = papers.student_id GROUP BY name ORDER BY average DESC;
-- SELECT name, IFNULL(SUM(grade)/COUNT(*), 0) AS 'average', 
-- CASE WHEN AVG(grade) IS NULL THEN 'FAILING' WHEN AVG(grade) >= 75 THEN 'PASSING' ELSE 'FAILING' END AS 'RWETYUIK'
--  FROM students LEFT JOIN papers ON students.id = papers.student_id GROUP BY name ORDER BY average DESC;



-- CREATE TABLE reviewers(
-- 	id INT PRIMARY KEY AUTO_INCREMENT,
-- 	first_name VARCHAR(100),
-- 	last_name VARCHAR(100)
-- );

-- CREATE TABLE series(
-- 	id INT PRIMARY KEY AUTO_INCREMENT,
-- 	title VARCHAR(100),
-- 	released_year YEAR(4),
-- 	genre VARCHAR(100)
-- );

-- CREATE TABLE reviews(
-- 	id INT PRIMARY KEY AUTO_INCREMENT,
-- 	rating DECIMAL(2,1),
-- 	series_id INT,
-- 	reviewer_id INT,
-- 	FOREIGN KEY(series_id) REFERENCES series(id),
-- 	FOREIGN KEY(reviewer_id) REFERENCES reviewers(id)
-- );


    

-- SELECT title, rating FROM series JOIN reviews ON series.id = reviews.series_id LIMIT 15;
-- SELECT title, AVG(rating) AS 'avg_rating' FROM series JOIN reviews ON series.id = reviews.series_id GROUP BY series.id ORDER BY avg_rating, title;
-- SELECT first_name, last_name, rating FROM reviewers JOIN reviews ON reviewers.id = reviews.reviewer_id LIMIT 20;
-- SELECT title, rating FROM series LEFT JOIN reviews ON series.id = reviews.series_id WHERE reviews.series_id IS NULL; 
-- SELECT
-- first_name, last_name, 
-- COUNT(rating), IFNULL(MIN(rating), 0) AS 'MIN', IFNULL(MAX(rating), 0) AS 'MAX', IFNULL(AVG(rating), 0) AS 'AVG',
-- CASE WHEN COUNT(rating) = 0 THEN 'INACTIVE' ELSE 'ACTIVE' END AS 'STATUS'
-- FROM reviewers LEFT JOIN reviews
-- 	ON reviewers.id = reviews.reviewer_id
-- 	GROUP BY first_name, last_name;
-- SELECT 
-- title, rating, CONCAT(first_name, " ", last_name) AS 'reviewer'
-- FROM series JOIN reviews JOIN reviewers
-- 	ON series.id = reviews.series_id 
-- 	AND reviewers.id = reviews.reviewer_id
-- ORDER BY title LIMIT 15;




-- CREATE TABLE users (
--     id INTEGER AUTO_INCREMENT PRIMARY KEY,
--     username VARCHAR(255) UNIQUE NOT NULL,
-- 	created_at TIMESTAMP DEFAULT NOW()
-- );
-- CREATE TABLE photos(
-- 	id INT AUTO_INCREMENT PRIMARY KEY,
-- 	image_url VARCHAR(255) NOT NULL,
-- 	user_id INT NOT NULL,
-- 	created_at TIMESTAMP DEFAULT NOW(),
-- 	FOREIGN KEY(user_id) REFERENCES users(id)
-- );
-- CREATE TABLE comments(
-- 	id INT AUTO_INCREMENT PRIMARY KEY,
-- 	comment_text VARCHAR(255) NOT NULL,
-- 	user_id INT NOT NULL,
-- 	photo_id INT NOT NULL,
-- 	created_at TIMESTAMP DEFAULT NOW(),
-- 	FOREIGN KEY(user_id) REFERENCES users(id),
-- 	FOREIGN KEY(photo_id) REFERENCES photos(id)
-- );
-- CREATE TABLE likes(
-- 	user_id INT NOT NULL,
-- 	photo_id INT NOT NULL,
-- 	created_at TIMESTAMP DEFAULT NOW(),
-- 	FOREIGN KEY(user_id) REFERENCES users(id),
-- 	FOREIGN KEY(photo_id) REFERENCES photos(id),
-- 	PRIMARY KEY(user_id, photo_id) -- we need the primary key to avoid duplication of likes
-- );
-- CREATE TABLE follows(
-- 	follower_id INT NOT NULL,
-- 	followee_id INT NOT NULL,
-- 	created_at TIMESTAMP DEFAULT NOW(),
-- 	FOREIGN KEY(follower_id) REFERENCES users(id),
-- 	FOREIGN KEY(followee_id) REFERENCES users(id),
-- 	PRIMARY KEY(follower_id, followee_id)
-- );
-- CREATE TABLE tags(
-- 	id INT AUTO_INCREMENT PRIMARY KEY,
-- 	tag_name VARCHAR(255) UNIQUE,
-- 	created_at TIMESTAMP DEFAULT NOW()
-- );
-- CREATE TABLE photo_tags(
-- 	photo_id INT NOT NULL,
-- 	tag_id INT NOT NULL,
-- 	FOREIGN KEY(photo_id) REFERENCES photos(id),
-- 	FOREIGN KEY(tag_id) REFERENCES tags(id),
-- 	PRIMARY KEY(photo_id, tag_id)
-- );

-- SELECT * FROM users ORDER BY created_at LIMIT 5;
-- SELECT
-- 	DAYNAME(ROUND(AVG(DAYOFWEEK(created_at)), 0)) FROM users; -- WRONG!
-- SELECT
-- 	DAYNAME(created_at) AS 'lala',
-- 	COUNT(*) AS 'COUNT'
-- FROM users
-- 	GROUP BY lala
-- 	ORDER BY COUNT DESC
-- 	LIMIT 2;
-- SELECT username, image_url
-- FROM users LEFT JOIN photos
-- 	ON users.id = photos.user_id
-- 	WHERE image_url IS NULL -- pwede ring WHERE photos.id IS NULL
-- 	GROUP BY username;
-- SELECT
-- 	username, photos.id, image_url, COUNT(*) AS 'total'
-- FROM
-- 	users JOIN photos
-- 	ON
-- 		users.id = photos.user_id
-- 	JOIN likes
-- 	ON
-- 		photos.id = likes.photo_id
-- GROUP BY photos.id
-- ORDER BY total DESC
-- LIMIT 1;
-- SELECT
-- SELECT tag_name, COUNT(tag_id) AS 'gtag' FROM photo_tags JOIN tags ON photo_tags.tag_id = tags.id GROUP BY tag_id ORDER BY gtag DESC;
-- SELECT username, COUNT(*) AS 'guser' FROM likes JOIN users ON users.id = likes.user_id GROUP BY user_id HAVING guser = 257 ORDER BY guser DESC;
-- SELECT username, COUNT(*) AS 'pepe' FROM likes JOIN users ON users.id = likes.user_id GROUP BY username HAVING pepe = 257; 

-- SHOW DATABASES;
USE join_us;


-- SELECT  DATE_FORMAT(created_at, "%M %D %Y") AS earliest_Date FROM users ORDER BY created_at LIMIT 1;
-- SELECT MONTHNAME(created_at) AS 'month', COUNT(*) AS 'ye' FROM users GROUP BY month ORDER BY ye DESC;
-- SELECT COUNT(*) AS 'yahoo_users' FROM users WHERE email LIKE '%yahoo.com';
-- SELECT CASE
-- 			WHEN email LIKE '%yahoo.com' THEN 'yahoo'
-- 			WHEN email LIKE '%gmail.com' THEN 'gmail'
-- 			WHEN email LIKE '%hotmail.com' THEN 'hotmail'
-- 			ELSE 'other'
-- 		END AS 'provider',
-- 		COUNT(*) AS total_users
-- FROM users
-- 	GROUP BY provider;
-- DELETE FROM users;
-- SELECT * FROM users ORDER BY created_at DESC;

-- SHOW TABLES;

DESC users;
-- select * from users;



